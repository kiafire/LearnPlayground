import UIKit

//String Compression
//1. aaabbcdddd should be converted to a3b2c1d4
//2.abc should remain abc, since the compressed string is larger than this

func getCompressedString(input :String)-> String {
    var inputData = input
    var compressedStr = ""
    while !inputData.isEmpty {
      compressedStr += getCompressedSubString(input: &inputData, element: inputData.first!)
    }
    return (compressedStr.count < input.count ) ? compressedStr : input
}

func getCompressedSubString(input: inout String, element:Character) -> String {
    let str = input.drop(while: { $0 == element
    })
    print(str)
    print(input)
    let elementCompressed = "\(element)\( input.count - str.count)"
    input = String(str)

    return elementCompressed
}

getCompressedString(input: "aaabbcccdd")

getCompressedString(input: "abcd")

//

extension StringProtocol  {
    var digits: [Int] {
        return compactMap{ $0.wholeNumberValue }
    }
}
extension LosslessStringConvertible {
    var converter: String { return String(self) }
}

extension Numeric where Self: LosslessStringConvertible {
    var digits: [Int] { return converter.digits }
}

func returnNumber(start: Int , end : Int) -> Int{
    var started = start
    var total = 0
    repeat{
        print(started)
        let digits = started.digits.filter { $0 == 2
        }
        print(digits)
        total += digits.count
        started = started + 1
    } while (started <= end )
    return total
}

returnNumber(start: 0, end: 25)


func returnNumberWithoutProtocol(start: Int , end : Int) -> Int{
    var started: String
    var total = 0
    var currentIndex = start
    repeat{
        started = String(currentIndex)
        let digits = started.compactMap { $0.wholeNumberValue
            }.filter { $0 == 2 }
        print(digits)
        total += digits.count
        currentIndex = Int(started)!
        currentIndex = currentIndex + 1
    } while (currentIndex <= end )
    return total
}

returnNumberWithoutProtocol(start: 0, end: 25)
